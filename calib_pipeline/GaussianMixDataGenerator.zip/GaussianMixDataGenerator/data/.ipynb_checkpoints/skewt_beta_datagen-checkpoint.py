from scipy.stats import norm
from scipy.stats import uniform
from random import seed
from random import randint
from random import random
import numpy as np
from GaussianMixDataGenerator.data.skewt_distributions import mixture
from sklearn.datasets import make_spd_matrix as spd
from scipy.stats import dirichlet
from sklearn import metrics
from scipy.stats import multivariate_normal as mvn
from scipy.stats import truncnorm
from skewt_scipy.skewt import skewt
from scipy.stats import skewcauchy

from scipy.stats import beta 
from matplotlib import pyplot as plt
from mpl_toolkits import mplot3d
import pdb as pdb
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split


class TruncSkewT():
    def __init__(self, a, df, loc, scale, lo=0, hi=1):
        self.a = a
        self.scale = scale
        self.df = df
        self.loc = loc
        self.lo = lo
        self.hi = hi

    def pdf(self,x):
        #print(f"min(x): {min(x)}, max(x): {max(x)}; low: {self.lo}; high: {self.hi}.")
        if (x >= self.lo).all() and (x <= self.hi).all():
            #print(f"!!! low: {self.lo}; high: {self.hi}.")
            skewt_dist = skewt(a= self.a, df=self.df, loc=self.loc, scale=self.scale)
            pdf = skewt_dist.pdf(x)
            cdf_a = skewt_dist.cdf(self.lo)
            cdf_b = skewt_dist.cdf(self.hi)
            norm_factor = cdf_b - cdf_a
            result = pdf / norm_factor
            return result
        #skewt.pdf(x, a= self.a, df=self.df, loc=self.loc, scale=self.scale)/(skewt.cdf(self.hi, a=self.a, df=self.df, loc=self.loc, scale=self.scale) - skewt.cdf(self.lo, a=self.a, df=self.df, loc=self.loc, scale=self.scale));
        return 0

    def rvs(self, size, random_state=123):
        lst = []
        #print(len(lst), size)
        if (isinstance(size, list)):
            size = size[0]
        while(len(lst)) < size:
            #print(f"current parameters: {self.a}, {self.df}, {self.loc}, {self.scale}")
            x = skewt.rvs(a= self.a, df= self.df, loc=self.loc, scale=self.scale, size=1)
            if x >= self.lo and x <= self.hi:
                lst.append(x)
        return np.array(lst)

class TruncCauchy():
    def __init__(self, a, loc, scale, lo=0, hi=1):
        self.a = a
        self.scale = scale
        self.loc = loc
        self.lo = lo
        self.hi = hi

    def pdf(self,x):
        if (x >= self.lo).all() and (x <= self.hi).all():
            skewc_dist = skewcauchy(a= self.a, loc=self.loc, scale=self.scale)
            pdf = skewc_dist.pdf(x)
            cdf_a = skewc_dist.cdf(self.lo)
            cdf_b = skewc_dist.cdf(self.hi)
            norm_factor = cdf_b - cdf_a
            result = pdf / norm_factor
            return result
        return 0

    def rvs(self, size, random_state=123):
        lst = []
        if (isinstance(size, list)):
            size = size[0]
        while(len(lst)) < size:
            #print(f"current parameters: {self.a}, {self.df}, {self.loc}, {self.scale}")
            x = skewcauchy.rvs(a= self.a, loc=self.loc, scale=self.scale, size=1)
            if x >= self.lo and x <= self.hi:
                lst.append(x)
        return np.array(lst)

class DataGenerator:

    def __init__(self, dist_p, dist_n, alpha):
        self.dist_p = dist_p
        self.dist_n = dist_n
        self.alpha = alpha

        
    def data_pos(self, n):
        #posx = self.dist_p.comps[0].rvs(size=1000000)
        #prop = sum((posx>=0)&(posx<=1))/1000000
        #print(f"pos data n/prop: {n}, {prop})")
        #n = int(n/prop)
        #pdb.set_trace()
        #print(f"pos n: {n}")
        if isinstance(self.dist_p, mixture):
            x, c = self.dist_p.rvsCompInfo(size=n)
            x = np.reshape(x, newshape=(n, -1))
        else:
            #pdb.set_trace()
            x = np.reshape(self.dist_p.rvs(size=(n,1)), newshape=(n, -1))
            c = np.ones((x.shape[0], 1))
        
        return x, c

    def data_neg(self, n):
        #posx = self.dist_n.comps[0].rvs(size=1000000)
        #prop = sum((posx>=0)&(posx<=1))/1000000
        #print(f"neg data n/prop: {n}, {prop})")
        #n = int(n/prop)
        #print(f"neg n: {n}")
        if isinstance(self.dist_n, mixture):
            x, c = self.dist_n.rvsCompInfo(size=n)
            x = np.reshape(x, newshape=(n, -1))
        else:
            x = np.reshape(self.dist_n.rvs(size=(n, 1)), newshape=(n, -1))
            c = np.ones((x.shape[0], 1))
        return x, c

    def data_pos_compInfo(self, n):
        #pdb.set_trace()
        x, c = self.dist_p.rvsCompInfo(size=n)
        x = np.reshape(x, newshape=(n, -1))
        return x, c

    def data_neg_compInfo(self, n):
        x, c = self.dist_n.rvsCompInfo(size=n)
        x = np.reshape(x, newshape=(n, -1))
        return x, c


    def pu_data(self, n_p, n_u, alpha = None):
        if alpha == None:
            alpha = self.alpha
        x_p, c_p = self.data_pos(n_p)
        x_u, y_u, c_u = self.pn_data(n_u, alpha)
        x_pu = np.concatenate((x_p, x_u), axis=0)
        y_pu = np.zeros([x_pu.shape[0], 1])
        y_pu[np.arange(n_p), 0] = 1
        y_pn = np.vstack((np.ones([n_p, 1]), y_u))
        c_pu = np.vstack((c_p, c_u))
        # y_pn = y_pu
        # y_pn[x_pu.size(0):(self.n_p - 1):-1, 0] = y_u
        return x_pu, y_pu, y_pn, c_pu, x_p, x_u, y_u, c_p, c_u
        
    def pn_data(self, n, alpha=None):
        if alpha == None:
            alpha = self.alpha
        n_p = np.cast['int32'](np.floor(n * alpha))
        n_n = n - n_p
        x_p, c_p = self.data_pos(n_p)
        x_n, c_n = self.data_neg(n_n)
        y_p = np.ones((x_p.shape[0], 1))
        y_n = np.zeros((x_n.shape[0], 1))
        x = np.vstack((x_p, x_n))
        y = np.vstack((y_p, y_n))
        c = np.vstack((c_p, c_n))
        return x, y, c, x_p, x_n, c_p, c_n
    
    def dens_pos(self, x):
        return self.dist_p.pdf(x)

    def dens_neg(self, x):
        return self.dist_n.pdf(x)

    def dens_mix(self, x, alpha = None):
        if alpha == None:
            alpha = self.alpha
        return alpha * self.dens_pos(x) + (1 - alpha) * self.dens_neg(x)

    def pn_posterior(self, x, alpha = None):
        if alpha == None:
            alpha = self.alpha
        #print(alpha, self.dens_pos(x))
        #print(alpha, self.dens_mix(x,alpha))
        return alpha * self.dens_pos(x) / self.dens_mix(x, alpha)

    def pu_posterior(self, x, n_p, n_u, alpha=None):
        if alpha == None:
            alpha = self.alpha
        n_up = np.cast['int32'](np.floor(n_u * alpha))
        c1 = n_p / (n_u + n_p)
        c2 = (n_up + n_p) / (n_u + n_p)
        return c1 * self.dens_pos(x) / self.dens_mix(x, c2)

    def pn_posterior_sts(self, x, n_p, n_u, alpha = None):
        if alpha == None:
            alpha = self.alpha
        n_up = np.cast['int32'](np.floor(n_u * alpha))
        c = (n_up + n_p) / (self.n_u + self.n_p)
        return self.pn_posterior(x, c)

    def pn_posterior_cc(self, x):
        return self.pn_posterior(x, self.alpha)

    def pn_posterior_balanced(self, x):
        return self.pn_posterior(x, 0.5)


class GaussianDG(DataGenerator):

    def __init__(self, mu, sig, alpha):
        dist_p = norm(loc=0, scale=1)
        dist_n = norm(loc=mu, scale=sig)
        super(GaussianDG, self).__init__(dist_p=dist_p, dist_n=dist_n, alpha=alpha)

        
class UniformDG(DataGenerator):

    def __init__(self, mu, sig, alpha):
        self.dist_p = uniform(loc=0, scale=1)
        self.dist_n = uniform(loc=mu, scale=sig)
        super(UniformDG, self).__init__(dist_p=self.dist_p, dist_n=self.dist_n, alpha=alpha)


class NormalMixDG(DataGenerator):

    def __init__(self, mu_pos, sig_pos, p_pos, mu_neg, sig_neg, p_neg, alpha):
        components_pos = [norm(loc=mu, scale=sig) for (mu, sig) in zip(mu_pos, sig_pos)]
        components_neg = [norm(loc=mu, scale=sig) for (mu, sig) in zip(mu_neg, sig_neg)]
        self.dist_pos = mixture(components_pos, p_pos)
        self.dist_neg = mixture(components_neg, p_neg)
        super(NormalMixDG, self).__init__(dist_p=self.dist_pos, dist_n=self.dist_neg, alpha=alpha)


class MVNormalMixDG(DataGenerator):

    #def __init__(self, mu_pos, sig_pos, p_pos, mu_neg, sig_neg, p_neg, alpha):
    def __init__(self, pos_params, p_pos, neg_params, p_neg, alpha):
        #self.components_pos = [mvn(mean=mu, cov=sig) for (mu, sig) in zip(mu_pos, sig_pos)]
        self.components_pos = [truncnorm(*pos_params)]
        self.components_neg = [truncnorm(*neg_params)]
        #self.components_neg = [mvn(mean=mu, cov=sig) for (mu, sig) in zip(mu_neg, sig_neg)]
        dist_p = mixture(self.components_pos, p_pos)
        dist_n = mixture(self.components_neg, p_neg)
        super(MVNormalMixDG, self).__init__(dist_p=dist_p, dist_n=dist_n, alpha=alpha)

    def updateMixProps(self, alpha=None, p_pos=None, p_neg=None):
        if p_pos is not None:
            self.dist_p = mixture(self.components_pos, p_pos)
        if p_neg is not None:
            self.dist_n = mixture(self.components_neg, p_neg)
        if alpha is not None:
            self.alpha = alpha

    def printInfo(self):
        print("Positive Data Information")
        self.dist_p.printInfo()
        print("Negative Data Information")
        self.dist_n.printInfo()


class BetaDG(DataGenerator):

    def __init__(self, a_pos, b_pos, p_pos, a_neg, b_neg, p_neg, alpha):
        self.components_pos = [beta(a, b) for (a, b) in zip(a_pos, b_pos)]
        self.components_neg = [beta(a, b) for (a, b) in zip(a_neg, b_neg)]
        dist_p = mixture(self.components_pos, p_pos)
        dist_n = mixture(self.components_neg, p_neg)
        super(BetaDG, self).__init__(dist_p=dist_p, dist_n=dist_n, alpha=alpha)

class TruncCauchyDG(DataGenerator):

    def __init__(self, a_pos, loc_pos, scale_pos, lo_pos, hi_pos, p_pos, 
                 a_neg, loc_neg, scale_neg, lo_neg, hi_neg, p_neg, alpha):
        self.components_pos = [TruncCauchy(a, loc, scale, lo_pos, hi_pos) for (a, loc, scale, lo_pos, hi_pos) in zip(a_pos, loc_pos, scale_pos, lo_pos, hi_pos)]
        self.components_neg = [TruncCauchy(a, loc, scale, lo_neg, hi_neg) for (a, loc, scale, lo_neg, hi_neg) in zip(a_neg, loc_neg, scale_neg, lo_neg, hi_neg)]
        dist_p = mixture(self.components_pos, p_pos)
        dist_n = mixture(self.components_neg, p_neg)
        super(TruncCauchyDG, self).__init__(dist_p=dist_p, dist_n=dist_n, alpha=alpha)


class Beta_TruncSkewTDG(DataGenerator):
    ''' pos: Beta; neg: skewt '''
    def __init__(self, a_pos, b_pos, p_pos, 
                 a_neg, df_neg, loc_neg, scale_neg, lo_neg, hi_neg, p_neg, alpha):
        self.components_pos = [beta(a, b) for (a, b) in zip(a_pos, b_pos)]
        self.components_neg = [TruncSkewT(a, df, loc, scale, lo_neg, hi_neg) for (a, df, loc, scale, lo_neg, hi_neg) in zip(a_neg, df_neg, loc_neg, scale_neg, lo_neg, hi_neg)]
        dist_p = mixture(self.components_pos, p_pos)
        dist_n = mixture(self.components_neg, p_neg)
        super(Beta_TruncSkewTDG, self).__init__(dist_p=dist_p, dist_n=dist_n, alpha=alpha)    


class TruncSkewT_TruncCauchyDG(DataGenerator):
    ''' pos: skewt; neg: cauchy'''
    def __init__(self, a_pos, df_pos, loc_pos, scale_pos, lo_pos, hi_pos, p_pos, 
                 a_neg, loc_neg, scale_neg, lo_neg, hi_neg, p_neg, alpha):
        self.components_pos = [TruncSkewT(a, df, loc, scale, lo_pos, hi_pos) for (a, df, loc, scale, lo_pos, hi_pos) in zip(a_pos, df_pos, loc_pos, scale_pos, lo_pos, hi_pos)]
        self.components_neg = [TruncCauchy(a, loc, scale, lo_neg, hi_neg) for (a, loc, scale, lo_neg, hi_neg) in zip(a_neg, loc_neg, scale_neg, lo_neg, hi_neg)]
        dist_p = mixture(self.components_pos, p_pos)
        dist_n = mixture(self.components_neg, p_neg)
        super(TruncSkewT_TruncCauchyDG, self).__init__(dist_p=dist_p, dist_n=dist_n, alpha=alpha)

class TruncCauchy_TruncSkewTDG(DataGenerator):
    ''' pos: cauchy; neg: skewt'''
    def __init__(self, a_pos, loc_pos, scale_pos, lo_pos, hi_pos, p_pos, 
                 a_neg, df_neg, loc_neg, scale_neg, lo_neg, hi_neg, p_neg, alpha):
        self.components_pos = [TruncCauchy(a, loc, scale, lo_pos, hi_pos) for (a, loc, scale, lo_pos, hi_pos) in zip(a_pos, loc_pos, scale_pos, lo_pos, hi_pos)]
        self.components_neg = [TruncSkewT(a, df, loc, scale, lo_neg, hi_neg) for (a, df, loc, scale, lo_neg, hi_neg) in zip(a_neg, df_neg, loc_neg, scale_neg, lo_neg, hi_neg)]
        dist_p = mixture(self.components_pos, p_pos)
        dist_n = mixture(self.components_neg, p_neg)
        super(TruncCauchy_TruncSkewTDG, self).__init__(dist_p=dist_p, dist_n=dist_n, alpha=alpha)    