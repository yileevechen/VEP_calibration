#!/bin/bash
#BSUB -J simu_am                           # Job name
#BSUB -P acc_pejaverlab   # allocation account
#BSUB -q express                                  # queue
#BSUB -n 3                                            # number of compute cores = 1
#BSUB -R rusage[mem=2000]              # 8GB of memory
#BSUB -W 1:00                                   # walltime in HH:MM
#BSUB -o exprun.stdout                              # output log (%J : JobID)
#BSUB -eo exprun.stderr                             # error log
#BSUB -L /bin/bash                               # Initialize the execution environment

source activate calibrate_para

python examples/example.py
