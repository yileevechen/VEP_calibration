import sys
sys.path.append("/sc/arion/projects/pejaverlab/IGVF/users/cheny60/analysis/calibrationexp-main/mave_calibration-master")

from mave_calibration.plotting.generate_aggregate_figs import get_lrPlus, prior_from_weights,get_score_thresholds, predict
from mave_calibration.main import single_fit, load_data

import os
from pathlib import Path
import pandas as pd
import numpy as np
import json
import jsonpickle

def serialize(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")

def runExample():
    # location of this file
    pth = os.path.dirname(os.path.abspath(__file__))
    # dataset name
    dataset_name = "ClinVar" #"Findlay_BRCA1_SGE"
    # dataset directory
    dataset_dir = Path(os.path.join(pth,dataset_name))
    observations, sample_indicators, sample_names = load_data(data_filepath=dataset_dir / "clinvdat.csv") # "samples.csv")
    # run the calibration
    bestFitres = single_fit(observations, sample_indicators,
                   max_iters=10000, n_inits=100, verbose=True)
    print("\n____",bestFitres,"____\n")
    class AttrDict(dict):
        def __getattr__(self, name):
            try:
                return self[name]
            except KeyError:
                raise AttributeError(f"'AttrDict' object has no attribute '{name}'")

        def __setattr__(self, name, value):
            self[name] = value
    
    bestFit = AttrDict(bestFitres)
    with open("expfit.json", "w") as f:
        f.write(jsonpickle.encode(bestFitres))

    print_results(observations, sample_names, bestFit)


def print_results(observations, sample_names, bestFit):
    score_range =np.arange(observations.min(), observations.max(), .01)
    lrPlus = get_lrPlus(score_range, sample_names.index('B/LB'), bestFit)
    prior = prior_from_weights(bestFit.weights,
                                    controls_idx=sample_names.index('B/LB'))
    print(f"\n!!!!prior res:___________{prior}___________!!!!\n")

    #LR_curves = predict(X= score_range, control_sample_index= sample_names.index('B/LB'), results = bestFit, posterior=True, priors = prior, return_all=True)
    #print(f"\n!!!!___________{LR_curves}___________!!!!\n")
    #pathogenic_score_thresholds, benign_score_thresholds = get_score_thresholds(lrPlus, prior, score_range)
    #print("Pathogenic score thresholds:")
    #for num_points, score_threshold in zip("+1 +2 +3 +4 +8".split(" "), pathogenic_score_thresholds):
    #    print(f"{num_points}: {'-------' if np.isnan(score_threshold) else np.round(score_threshold,4)}")
    #print("Benign score thresholds:")
    #for num_points, score_threshold in zip("-1 -2 -3 -4 -8".split(" "), benign_score_thresholds):
    #    print(f"{num_points}: {'-------' if np.isnan(score_threshold) else np.round(score_threshold,4)}")
    #print(f"estimated prior: {prior:.4f}")

if __name__ == '__main__':
    runExample()
